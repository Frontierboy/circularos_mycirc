const Dashboard = () => (
  <div>
    <h1>Dashboard</h1>
    <p>This is a protected route.</p>
  </div>
);

export default Dashboard;
