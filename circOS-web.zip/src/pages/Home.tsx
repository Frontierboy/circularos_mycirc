const Home = () => (
  <div>
    <h1>Welcome to CircOS</h1>
    <p>This is the circular economy operating system.</p>
  </div>
);

export default Home;
